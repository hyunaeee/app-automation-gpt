# Android source

This app contains the generated web assets in a native Android WebView. It runs offline and stores data on the device. Network access, native JavaScript bridges, file access and external navigation are disabled.

Open this folder in Android Studio, select JDK 17, install Android SDK Platform 34 and Build Tools 34.0.0, and build the debug APK. Alternatively, with Gradle 8.4 installed, run:

```sh
gradle :app:assembleDebug
```

Android Studio can generate the Gradle wrapper. This export has no bundled Gradle distribution or signing keys. Output: app/build/outputs/apk/debug/app-debug.apk. Debug APKs are for testing; configure your own release signing and current store requirements before publishing.
